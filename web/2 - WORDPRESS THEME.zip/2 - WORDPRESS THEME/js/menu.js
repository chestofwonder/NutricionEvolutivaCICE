// JavaScript Document
jQuery(document).ready(function(){
		jQuery(".flaticon-menu48").click(function(){
			jQuery("#main_menu").toggle("hidden_mobile");
		});
});